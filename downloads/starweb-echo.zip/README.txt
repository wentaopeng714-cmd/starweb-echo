STARWEB ECHO / 星网回声 — living weave edition
Original interactive Canvas + WebAudio artwork. Open index.html in a modern browser. No external libraries, media, API keys or network dependencies.

PLAY
Tap silk to pluck. Slowly drag to stretch. Fast swipe to cut the strands you cross.
Tap a steady beat 3+ times near the same place: a 16-second motif keeps sending waves along surviving strands. Repeated tapping refreshes it; up to four motifs can overlap.
Hold intact silk, then release: loosen nearby stars into the sky. Hold near a tear: stitch up to 16 nearby broken strands and recapture nearby drifting lights.
Falling stars gather below. Touch a star to scoop nearby stars, carry them onto the web, then release to seed a new cluster. This gesture never cuts the web.
Drag the tiny white weaver to a tear to guide repairs. Repaired regions gain golden cross threads. Guide it onto intact silk to add a local weave.
The weaver repairs continuously while you cut, drag, or hold. The web can be dismantled and reseeded repeatedly.
Sound starts muted. Use the note button to enable. Reset restores the initial web and all play states, preserving sound preference.

LIMITS
969 physics nodes. 1936 initial strands, maximum 2064 after weaving. Maximum 420 transient particles, 65 stars, 18 visual ripples, 12 traveling wavefronts and 4 repeating motifs.

PROVENANCE
Original code, geometry, synthesized sounds and visual design. Inspired by the observed web/star/falling-light premise of 思花《拾光》; no original media or code used.

QA
Chromium desktop 1440x900 and mobile 390x844 with real CDP touch input. Sustained 90+ second sequences cover rhythm, bloom, catch/reseed, cut, pulse-mend, spider guidance, idle repairs, reset and audio unlock. Physical iOS and Android devices are not tested.

VISUAL REVISION
44 spokes x 22 rings, 78% more base connections. Ordinary silk width 0.82 CSS px (previously 0.55); circular/radial opacity 0.48/0.62 (previously 0.28/0.38). Darker navy-to-deep-blue background and restrained gold halos. Existing interaction rules unchanged.

CONCURRENT REPAIR
Automatic repair does not wait for pointer release or idle. Fresh breaks remain open for at least 0.45 seconds. The weaver approaches at 720 CSS px/s and traverses the broken strand at 1050 px/s with a minimum visible stitch phase of 0.045 seconds. Nearby recent tears are prioritized; manual weaver guidance retains priority.
